#!/usr/bin/env python3
"""Katalog bütünlük doğrulaması.

Her aşamadan sonra çalıştırılır. Mevcut HTML içindeki catalog dizisini
okur ve korunması gereken değişmezleri kontrol eder.

Kullanım:
    python3 araclar/dogrula_katalog.py <html-dosyasi>

Çıkış kodu 0: tüm kontroller geçti. 0 dışı: ihlal var.
"""
import hashlib
import json
import re
import sys

# Aşama 0 başlangıcında kaydedilen değişmezler
BASELINE = {
    "kayit_sayisi": 517,
    "film": 339,
    "dizi": 178,
    "tekil_id": 517,
    "en_buyuk_film_id": "F-339",
    "en_buyuk_dizi_id": "D-178",
}


def katalog_oku(html):
    m = re.search(r"const catalog=(\[.*?\]);\s*\n", html, re.S)
    if not m:
        raise SystemExit("HATA: catalog dizisi bulunamadi.")
    return json.loads(m.group(1))


def main():
    if len(sys.argv) < 2:
        raise SystemExit("Kullanim: python3 araclar/dogrula_katalog.py <html-dosyasi>")
    path = sys.argv[1]
    raw = open(path, encoding="utf-8").read()
    cat = katalog_oku(raw)
    ids = [x["id"] for x in cat]

    hatalar = []

    def kontrol(ad, gercek, beklenen):
        ok = gercek == beklenen
        print(f"  [{'OK ' if ok else 'HATA'}] {ad}: {gercek} (beklenen {beklenen})")
        if not ok:
            hatalar.append(ad)

    print(f"Dosya: {path}")
    print(f"sha256: {hashlib.sha256(raw.encode('utf-8')).hexdigest()}")
    print("Kontroller:")
    kontrol("Kayit sayisi", len(cat), BASELINE["kayit_sayisi"])
    kontrol("Film sayisi", sum(1 for x in cat if x["kind"] == "Film"), BASELINE["film"])
    kontrol("Dizi sayisi", sum(1 for x in cat if x["kind"] == "Dizi"), BASELINE["dizi"])
    kontrol("Tekil ID", len(set(ids)), BASELINE["tekil_id"])

    film_ids = sorted(int(i.split("-")[1]) for i in ids if i.startswith("F-"))
    dizi_ids = sorted(int(i.split("-")[1]) for i in ids if i.startswith("D-"))
    kontrol("En buyuk film ID", f"F-{film_ids[-1]}", BASELINE["en_buyuk_film_id"])
    kontrol("En buyuk dizi ID", f"D-{dizi_ids[-1]}", BASELINE["en_buyuk_dizi_id"])

    # ID bosluğu kontrolü (eski kayitlar silinmemis olmali)
    f_gap = sorted(set(range(1, film_ids[-1] + 1)) - set(film_ids))
    d_gap = sorted(set(range(1, dizi_ids[-1] + 1)) - set(dizi_ids))
    kontrol("Film ID boslugu yok", f_gap, [])
    kontrol("Dizi ID boslugu yok", d_gap, [])

    # Zorunlu alan kontrolü
    eksik = sum(1 for x in cat if not all(x.get(k) for k in ("id", "title", "kind", "genre")))
    kontrol("Zorunlu alan eksigi yok", eksik, 0)

    print()
    if hatalar:
        print(f"SONUC: BASARISIZ ({len(hatalar)} ihlal): {', '.join(hatalar)}")
        return 1
    print("SONUC: TUM KONTROLLER GECTI")
    return 0


if __name__ == "__main__":
    sys.exit(main())
