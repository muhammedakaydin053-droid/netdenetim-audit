// İçerik uygunluğu — saf veri modeli, türetme ve doğrulama (DOM ve localStorage kullanmaz).
//
// Tasarım kararları (Aşama 3.4 / Adım 4):
// - Beş kategori ayrı ayrı tutulur; genel sonuç bu kategorilerden TÜRETİLİR.
// - Kaynak temelli başlangıç verisi (UYGUNLUK_TEMEL) ile kullanıcı düzeltmeleri
//   (ayrı localStorage anahtarı) hiçbir zaman birbirinin üzerine yazılmaz; birleştirilir.
// - Bilgi yokluğu `yok` DEĞİLDİR; `bilinmiyor` / `bekliyor` olarak kalır.
// - Bu adımda hiçbir kayıt için değerlendirme UYDURULMAZ; UYGUNLUK_TEMEL boştur.

const KATEGORILER = ['siddet', 'cinsellik', 'korkutucu', 'agirDil', 'madde'];
const KATEGORI_ETIKET = {
  siddet: 'Şiddet',
  cinsellik: 'Cinsellik / çıplaklık',
  korkutucu: 'Korkutucu içerik',
  agirDil: 'Ağır dil',
  madde: 'Madde kullanımı',
};
const SEVIYELER = ['yok', 'hafif', 'orta', 'yogun', 'bilinmiyor'];
const SONUCLAR = ['birlikte-uygun', 'uyari-ile', 'uygun-degil', 'bekliyor'];
const DURUMLAR = ['degerlendirildi', 'kismen-degerlendirildi', 'kaynak-bulunamadi', 'incelenmemis', 'kullanici-duzeltmesi'];
const GUVENLER = ['yuksek', 'orta', 'dusuk'];

// Genel sonucu kategori seviyelerinden TÜRETİR. Tek doğruluk kaynağı budur;
// kayıtlarda saklanan `sonuc` alanı bununla eşleşmek zorundadır (bkz. kayitDogrula).
//   - tüm kategoriler bilinmiyor / kategori yok        → bekliyor
//   - herhangi bir kategori yogun                      → uygun-degil
//   - herhangi bir kategori orta                       → uyari-ile
//   - herhangi bir kategori hafif                      → uyari-ile
//   - tüm kategoriler yok                              → birlikte-uygun
//   - kalan (yok + bilinmiyor karışık, hafif+ yok)     → bekliyor (eksik bilgi)
function sonucTuret(kategoriler) {
  if (!kategoriler || typeof kategoriler !== 'object' || Array.isArray(kategoriler)) return 'bekliyor';
  const degerler = KATEGORILER.map((k) => kategoriler[k]).filter((v) => v !== undefined);
  if (!degerler.length) return 'bekliyor';
  if (degerler.every((v) => v === 'bilinmiyor')) return 'bekliyor';
  if (degerler.some((v) => v === 'yogun')) return 'uygun-degil';
  if (degerler.some((v) => v === 'orta')) return 'uyari-ile';
  if (degerler.some((v) => v === 'hafif')) return 'uyari-ile';
  if (degerler.every((v) => v === 'yok')) return 'birlikte-uygun';
  return 'bekliyor';
}

// Sezon sonuçlarından dizi genel sonucunu türetir (en kötü sezon kuralı).
// Sezon verisi yoksa null döner; uydurma sezon üretilmez.
function sezonlardanSonuc(sezonlar) {
  if (!sezonlar || typeof sezonlar !== 'object' || Array.isArray(sezonlar)) return null;
  const sonuclar = Object.values(sezonlar)
    .map((s) => (s && typeof s === 'object' ? s.sonuc : undefined))
    .filter((s) => SONUCLAR.includes(s));
  if (!sonuclar.length) return null;
  const oncelik = { 'uygun-degil': 3, 'uyari-ile': 2, bekliyor: 1, 'birlikte-uygun': 0 };
  return sonuclar.reduce((en, s) => (oncelik[s] > oncelik[en] ? s : en), sonuclar[0]);
}

function seviyeGecerliMi(v) {
  return SEVIYELER.includes(v);
}
function kategoriGecerliMi(v) {
  return KATEGORILER.includes(v);
}
function sonucGecerliMi(v) {
  return SONUCLAR.includes(v);
}

// Bir uygunluk kaydını doğrular. Hiçbir şeyi DEĞİŞTİRMEZ; rapor ve temiz kopya döner.
// Çelişkili veri (saklanan sonuç ≠ türetilen sonuç) reddedilir.
// Dönen: { ok, hatalar: [ {field, reason} ], temiz }
function kayitDogrula(kayit) {
  const hatalar = [];
  const ekle = (field, reason) => hatalar.push({ field, reason });

  if (!kayit || typeof kayit !== 'object' || Array.isArray(kayit)) {
    return { ok: false, hatalar: [{ field: '(kayıt)', reason: 'kayıt nesne değil' }], temiz: null };
  }

  if ('id' in kayit && typeof kayit.id !== 'string') ekle('id', 'string değil');
  if (!kayit.id) ekle('id', 'id yok');

  // Kategoriler
  const temizKategoriler = {};
  if ('kategoriler' in kayit) {
    if (!kayit.kategoriler || typeof kayit.kategoriler !== 'object' || Array.isArray(kayit.kategoriler)) {
      ekle('kategoriler', 'nesne değil');
    } else {
      for (const [k, v] of Object.entries(kayit.kategoriler)) {
        if (!kategoriGecerliMi(k)) { ekle('kategoriler.' + k, 'bilinmeyen kategori'); continue; }
        if (!seviyeGecerliMi(v)) { ekle('kategoriler.' + k, 'geçersiz seviye: ' + v); continue; }
        temizKategoriler[k] = v;
      }
    }
  } else {
    ekle('kategoriler', 'kategoriler alanı yok');
  }

  // Genel sonuç tutarlılığı (saklanan sonuç, kategorilerden türetilenle eşleşmeli)
  if ('sonuc' in kayit && kayit.sonuc !== undefined && kayit.sonuc !== null) {
    if (!sonucGecerliMi(kayit.sonuc)) {
      ekle('sonuc', 'geçersiz sonuç: ' + kayit.sonuc);
    } else if (Object.keys(temizKategoriler).length) {
      const turetilen = sonucTuret(temizKategoriler);
      if (turetilen !== kayit.sonuc) {
        ekle('sonuc', 'çelişkili: saklanan=' + kayit.sonuc + ' türetilen=' + turetilen);
      }
    }
  }

  // Durum
  if ('durum' in kayit && kayit.durum !== undefined && !DURUMLAR.includes(kayit.durum)) {
    ekle('durum', 'geçersiz durum: ' + kayit.durum);
  }

  // Kaynaklar
  if ('kaynaklar' in kayit) {
    if (!Array.isArray(kayit.kaynaklar)) {
      ekle('kaynaklar', 'dizi değil');
    } else {
      kayit.kaynaklar.forEach((k, i) => {
        if (!k || typeof k !== 'object' || Array.isArray(k)) { ekle('kaynaklar[' + i + ']', 'nesne değil'); return; }
        if (typeof k.ad !== 'string' || !k.ad) ekle('kaynaklar[' + i + '].ad', 'kaynak adı yok');
        if ('guven' in k && !GUVENLER.includes(k.guven)) ekle('kaynaklar[' + i + '].guven', 'geçersiz güven: ' + k.guven);
        if ('kategoriler' in k && (!Array.isArray(k.kategoriler) || k.kategoriler.some((c) => !kategoriGecerliMi(c)))) {
          ekle('kaynaklar[' + i + '].kategoriler', 'geçersiz kategori listesi');
        }
      });
    }
  }

  // Sezonlar (yalnızca dizilerde anlamlı; yapı film/dizi için aynı kalır)
  if ('sezonlar' in kayit) {
    if (!kayit.sezonlar || typeof kayit.sezonlar !== 'object' || Array.isArray(kayit.sezonlar)) {
      ekle('sezonlar', 'nesne değil');
    } else {
      for (const [s, sv] of Object.entries(kayit.sezonlar)) {
        if (!sv || typeof sv !== 'object' || Array.isArray(sv)) { ekle('sezonlar.' + s, 'nesne değil'); continue; }
        if (sv.kategoriler && typeof sv.kategoriler === 'object') {
          for (const [k, v] of Object.entries(sv.kategoriler)) {
            if (!kategoriGecerliMi(k)) ekle('sezonlar.' + s + '.' + k, 'bilinmeyen kategori');
            else if (!seviyeGecerliMi(v)) ekle('sezonlar.' + s + '.' + k, 'geçersiz seviye: ' + v);
          }
        }
        if ('sonuc' in sv && sv.sonuc !== undefined && !sonucGecerliMi(sv.sonuc)) {
          ekle('sezonlar.' + s + '.sonuc', 'geçersiz sonuç: ' + sv.sonuc);
        }
      }
    }
  }

  const temiz = {
    id: kayit.id,
    kategoriler: temizKategoriler,
    sonuc: kayit.sonuc !== undefined ? kayit.sonuc : sonucTuret(temizKategoriler),
    durum: kayit.durum !== undefined ? kayit.durum : 'incelenmemis',
    kaynaklar: Array.isArray(kayit.kaynaklar) ? kayit.kaynaklar : [],
    kullaniciNotu: typeof kayit.kullaniciNotu === 'string' ? kayit.kullaniciNotu : '',
  };
  if ('sezonlar' in kayit) temiz.sezonlar = kayit.sezonlar;

  return { ok: hatalar.length === 0, hatalar, temiz };
}

// Kaynak temelli başlangıç verisini kullanıcı düzeltmesiyle birleştirir.
// Kaynak verisi ve kullanıcı kaydı AYRI kalır (ikisi de silinmez).
// Kullanıcı düzeltmesi yalnızca belirttiği alanları geçersiz kılar.
// Dönen: { id, gecerli, kaynak, kullanici, duzeltilenAlanlar }
function birlestir(temel, kullanici) {
  const kaynak = temel && typeof temel === 'object' ? temel : null;
  const kul = kullanici && typeof kullanici === 'object' ? kullanici : null;

  const kaynakKategoriler = kaynak && kaynak.kategoriler ? { ...kaynak.kategoriler } : {};
  const kulKategoriler = kul && kul.kategoriler ? { ...kul.kategoriler } : {};
  const gecerliKategoriler = { ...kaynakKategoriler, ...kulKategoriler };

  const duzeltilenAlanlar = [];
  for (const k of Object.keys(kulKategoriler)) {
    if (JSON.stringify(kaynakKategoriler[k]) !== JSON.stringify(kulKategoriler[k])) duzeltilenAlanlar.push('kategoriler.' + k);
  }
  if (kul && 'kullaniciNotu' in kul && kul.kullaniciNotu) duzeltilenAlanlar.push('kullaniciNotu');
  if (kul && 'sezonlar' in kul) duzeltilenAlanlar.push('sezonlar');

  const gecerli = {
    id: (kul && kul.id) || (kaynak && kaynak.id) || null,
    kategoriler: gecerliKategoriler,
    sonuc: sonucTuret(gecerliKategoriler),
    durum: kul && kul.durum ? kul.durum : (kaynak && kaynak.durum ? kaynak.durum : 'incelenmemis'),
    kaynaklar: (kaynak && kaynak.kaynaklar) || [],
    kullaniciNotu: (kul && kul.kullaniciNotu) || '',
    sezonlar: (kul && kul.sezonlar) || (kaynak && kaynak.sezonlar) || null,
  };

  return { id: gecerli.id, gecerli, kaynak, kullanici: kul, duzeltilenAlanlar };
}

// Uygulamayla gelen kaynak temelli başlangıç verisi. Bu adımda BOŞTUR:
// hiçbir kayıt için değerlendirme uydurulmaz. Kayıtlar `bekliyor` durumunda kalır.
const UYGUNLUK_TEMEL = {};

// Katalog + veri katmanlarından durum özeti üretir (517/517 hedefi için şeffaflık).
// Hiçbir kategoriye tahmini değer yazmaz; yalnızca mevcut durumu sayar.
function durumOzeti(katalog, temel, kullanici) {
  const t = temel && typeof temel === 'object' ? temel : {};
  const k = kullanici && typeof kullanici === 'object' ? kullanici : {};
  const ozet = {
    toplam: Array.isArray(katalog) ? katalog.length : 0,
    degerlendirildi: 0,
    kismenDegerlendirildi: 0,
    kaynakBulunamadi: 0,
    incelenmemis: 0,
    kullaniciDuzeltmeli: 0,
    bekliyor: 0,
  };
  const ids = Array.isArray(katalog) ? katalog.map((x) => x.id) : Object.keys(t);
  for (const id of ids) {
    const b = birlestir(t[id], k[id]);
    if (b.duzeltilenAlanlar.length) ozet.kullaniciDuzeltmeli++;
    if (b.gecerli.durum === 'degerlendirildi') ozet.degerlendirildi++;
    else if (b.gecerli.durum === 'kismen-degerlendirildi') ozet.kismenDegerlendirildi++;
    else if (b.gecerli.durum === 'kaynak-bulunamadi') ozet.kaynakBulunamadi++;
    else ozet.incelenmemis++;
    if (b.gecerli.sonuc === 'bekliyor') ozet.bekliyor++;
  }
  return ozet;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    KATEGORILER, KATEGORI_ETIKET, SEVIYELER, SONUCLAR, DURUMLAR, GUVENLER,
    sonucTuret, sezonlardanSonuc, seviyeGecerliMi, kategoriGecerliMi, sonucGecerliMi,
    kayitDogrula, birlestir, durumOzeti, UYGUNLUK_TEMEL,
  };
}
