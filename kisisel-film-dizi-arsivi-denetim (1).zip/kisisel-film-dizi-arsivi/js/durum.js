// Kullanıcı verisi katmanı: LocalStorage, yedekleme, geri alma.
// Anahtar ve mevcut alanlar (watched, favorite, rating, rank) korunur.

const KEY = 'personal-film-series-archive-v1';
const BACKUP_KEY = 'personal-film-series-archive-v1__backup';
// İçerik uygunluğu kullanıcı düzeltmeleri AYRI anahtarda tutulur (kaynak verisini ezmez).
const UYGUNLUK_KEY = 'personal-film-series-archive-v1__uygunluk';
const UYGUNLUK_BACKUP_KEY = 'personal-film-series-archive-v1__uygunluk-backup';

let state = {};
let uygunlukState = {};

// Uygunluk düzeltmelerini okur; bozuksa boş döner ve HAM veriyi SİLMEZ.
function loadUygunluk() {
  const raw = localStorage.getItem(UYGUNLUK_KEY);
  if (raw === null) { uygunlukState = {}; return { ok: true, durum: 'temiz' }; }
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      uygunlukState = parsed;
      return { ok: true, durum: 'guncel' };
    }
    uygunlukState = {};
    return { ok: false, error: 'Uygunluk verisi nesne değil; ham veri korundu.' };
  } catch (e) {
    uygunlukState = {};
    return { ok: false, error: 'Uygunluk verisi bozuk JSON; ham veri korundu.' };
  }
}

// Bir kaydın GEÇERLİ uygunluk verisini döndürür (kaynak temel + kullanıcı düzeltmesi).
function uygunlukGet(id) {
  return birlestir(UYGUNLUK_TEMEL[id], uygunlukState[id]);
}

// Kullanıcı düzeltmesi yazar. Kaynak verisine dokunmaz.
function uygunlukDuzelt(id, alan, deger) {
  const kayit = { ...(uygunlukState[id] || {}), id };
  if (alan === 'kategori') {
    kayit.kategoriler = { ...(kayit.kategoriler || {}), [deger.kategori]: deger.seviye };
  } else if (alan === 'kullaniciNotu') {
    kayit.kullaniciNotu = deger;
  } else if (alan === 'durum') {
    kayit.durum = deger;
  } else {
    kayit[alan] = deger;
  }
  uygunlukState[id] = kayit;
  uygunlukKaydet();
  return kayit;
}

function uygunlukKaydet() {
  localStorage.setItem(UYGUNLUK_KEY, JSON.stringify(uygunlukState));
}

// Uygunluk katmanının otomatik yedeğini alır (içe aktarma öncesi).
function uygunlukBackupAl() {
  try {
    localStorage.setItem(UYGUNLUK_BACKUP_KEY, JSON.stringify(uygunlukState));
    return true;
  } catch (e) {
    return false;
  }
}

function uygunlukGeriAl() {
  const raw = localStorage.getItem(UYGUNLUK_BACKUP_KEY);
  if (raw === null) return false;
  let parsed;
  try { parsed = JSON.parse(raw); } catch (e) { return false; }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return false;
  try {
    localStorage.setItem(UYGUNLUK_KEY, JSON.stringify(parsed));
  } catch (e) { return false; }
  uygunlukState = parsed;
  return true;
}

function getUygunlukRaw() {
  return uygunlukState;
}
function setUygunlukState(obj) {
  uygunlukState = obj && typeof obj === 'object' && !Array.isArray(obj) ? obj : {};
}

// Ham state'i okur (biçim doğrulaması yapar ama değiştirmez).
function okuHam() {
  const raw = localStorage.getItem(KEY);
  if (raw === null) return {};
  const parsed = JSON.parse(raw); // bozuksa hata yükselir; çağıran yakalar
  return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
}

// Migration meta verisini okur; bozuksa null döner.
function okuMeta() {
  const raw = localStorage.getItem(SEMA_META_KEY);
  if (raw === null) return {};
  try {
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : null;
  } catch (e) {
    return null; // bozuk meta → migrationPlanla reddeder
  }
}

// LocalStorage verisini yükler ve gerekiyorsa şema migration'ı uygular.
// Dönen: { ok, error?, durum? }  durum: 'temiz' | 'yeni' | 'migrate-edildi' | 'guncel'
function loadState() {
  let ham;
  try {
    ham = okuHam();
  } catch (e) {
    // Bozuk JSON: sessizce dönüştürme. Eski veriyi olduğu gibi bırak.
    state = {};
    return { ok: false, error: 'LocalStorage verisi bozuk JSON. Hiçbir veri değiştirilmedi.' };
  }

  const meta = okuMeta();
  const plan = migrationPlanla(ham, meta);

  if (!plan.ok) {
    // Desteklenmeyen/bozuk şema: veriyi değiştirme, bellekte olduğu gibi tut.
    state = ham;
    return { ok: false, error: plan.error };
  }

  if (!plan.gerekti) {
    state = ham;
    return { ok: true, durum: Object.keys(ham).length ? 'guncel' : 'temiz' };
  }

  // Taşınacak kayıt yoksa gereksiz migration/yedek yapma.
  if (Object.keys(ham).length === 0) {
    state = ham;
    return { ok: true, durum: 'temiz' };
  }

  // Migration gerekiyor. Önce yedek al; alınamazsa başlatma.
  if (!migrationBackupRaw(ham)) {
    state = ham;
    return { ok: false, error: 'Migration öncesi yedek alınamadı. Hiçbir veri değiştirilmedi.' };
  }

  // Atomik yazma: state değişmez, yalnızca meta yazılır. Hata olursa state korunur.
  const eskiMeta = localStorage.getItem(SEMA_META_KEY);
  try {
    localStorage.setItem(SEMA_META_KEY, JSON.stringify(plan.yeniMeta));
  } catch (e) {
    try {
      if (eskiMeta === null) localStorage.removeItem(SEMA_META_KEY);
      else localStorage.setItem(SEMA_META_KEY, eskiMeta);
    } catch (e2) { /* yok say */ }
    state = ham;
    return { ok: false, error: 'Migration sırasında yazma hatası. Mevcut veri korundu.' };
  }

  state = ham;
  return { ok: true, durum: 'migrate-edildi', rapor: plan.rapor, fromVersion: plan.fromVersion, toVersion: plan.toVersion };
}

// Verilen ham nesneyi yedek anahtarına yazar.
function backupRaw(veri) {
  try {
    localStorage.setItem(BACKUP_KEY, JSON.stringify(veri));
    return true;
  } catch (e) {
    return false;
  }
}

// Migration öncesi yedeği ayrı anahtara yazar (içe aktarma yedeğiyle çakışmaz).
function migrationBackupRaw(veri) {
  try {
    localStorage.setItem(MIGRATION_BACKUP_KEY, JSON.stringify(veri));
    return true;
  } catch (e) {
    return false;
  }
}

function get(id) {
  return state[id] || {};
}

function save() {
  localStorage.setItem(KEY, JSON.stringify(state));
  renderStats();
}

function update(id, field, value) {
  state[id] = { ...(state[id] || {}), [field]: value };
  save();
  render();
}

// Riskli işlemlerden önce mevcut veriyi ayrı anahtara yazar.
function backupNow() {
  return backupRaw(state);
}

function hasBackup() {
  return !!localStorage.getItem(BACKUP_KEY);
}

function restoreBackup() {
  const raw = localStorage.getItem(BACKUP_KEY);
  if (!raw) return false;
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (e) {
    return false;
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return false;

  // Geri alınan veri eski şema olabilir; meta'yı sıfırla ki migration yeniden değerlendirilsin.
  const eskiMeta = localStorage.getItem(SEMA_META_KEY);
  try {
    localStorage.removeItem(SEMA_META_KEY);
    localStorage.setItem(KEY, JSON.stringify(parsed));
  } catch (e) {
    try {
      if (eskiMeta !== null) localStorage.setItem(SEMA_META_KEY, eskiMeta);
    } catch (e2) { /* yok say */ }
    return false;
  }

  loadState();
  render();
  return true;
}
