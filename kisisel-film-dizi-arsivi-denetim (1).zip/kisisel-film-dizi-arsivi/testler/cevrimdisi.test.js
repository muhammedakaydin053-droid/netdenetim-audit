// Çevrimdışı (file://) test: yerel sunucu olmadan çift tıkla açılma koşulu.
// Çalıştırma: node testler/cevrimdisi.test.js
const puppeteer = require('puppeteer-core');
const path = require('path');

const EXEC = '/usr/bin/chromium';
const FILE_URL = 'file://' + path.resolve(__dirname, '..', 'index.html');

let gecen = 0, kalan = 0;
function esit(ad, gercek, beklenen) {
  const ok = JSON.stringify(gercek) === JSON.stringify(beklenen);
  console.log(`  [${ok ? 'OK ' : 'HATA'}] ${ad}` + (ok ? '' : ` → gerçek=${JSON.stringify(gercek)} beklenen=${JSON.stringify(beklenen)}`));
  ok ? gecen++ : kalan++;
}
function dogru(ad, kosul) {
  console.log(`  [${kosul ? 'OK ' : 'HATA'}] ${ad}`);
  kosul ? gecen++ : kalan++;
}

(async () => {
  const browser = await puppeteer.launch({ executablePath: EXEC, headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  const hatalar = [];
  page.on('pageerror', (e) => hatalar.push('pageerror: ' + e.message));
  page.on('requestfailed', (r) => hatalar.push('requestfailed: ' + r.url()));

  console.log('== Çevrimdışı (file://) yükleme ==');
  await page.goto(FILE_URL, { waitUntil: 'load' });
  await new Promise((r) => setTimeout(r, 500));

  esit('Toplam yapım = 517', await page.$eval('#total', (e) => e.textContent), '517');
  esit('Listede 517 kart', await page.$$eval('#list .item', (els) => els.length), 517);
  esit('Katalog yüklendi (517)', await page.evaluate(() => catalog.length), 517);
  esit('CSS uygulandı (koyu tema)', await page.evaluate(() => getComputedStyle(document.body).backgroundColor), 'rgb(16, 19, 26)');
  esit('Başarısız istek / hata yok', hatalar, []);

  // Çevrimdışı filtre + puanlama çalışmalı
  await page.evaluate(() => {
    const cb = [...document.querySelectorAll('#turPanel input[type="checkbox"]')].find((c) => c.value === 'Korku');
    cb.checked = true;
    cb.dispatchEvent(new Event('change', { bubbles: true }));
  });
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length > 0);
  esit('Korku filtresi = 36', await page.$$eval('#list .item', (els) => els.length), 36);
  await page.click('#reset');
  await page.evaluate(() => { const r = document.querySelector('#list .item .rating'); r.value = '8'; r.dispatchEvent(new Event('change', { bubbles: true })); });
  esit('Çevrimdışı puanlama çalıştı', await page.$eval('#rated', (e) => e.textContent), '1');
  await page.evaluate(() => { const r = document.querySelector('#list .item .rating'); r.value = ''; r.dispatchEvent(new Event('change', { bubbles: true })); });

  // Adım 2: etiket ve özellik filtreleri çevrimdışı da çalışmalı
  await page.evaluate(() => {
    const cb = [...document.querySelectorAll('#etPanel input[type="checkbox"]')].find((c) => c.value === 'Gençlik');
    cb.checked = true;
    cb.dispatchEvent(new Event('change', { bubbles: true }));
  });
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length === 10);
  esit('Çevrimdışı etiket Gençlik = 10', await page.$$eval('#list .item', (els) => els.length), 10);
  await page.click('#reset');

  await page.evaluate(() => {
    const b = [...document.querySelectorAll('#filtreEk .cip')].find((x) => x.dataset.alan === 'animasyonGelenegi' && x.dataset.deger === 'Anime');
    b.click();
  });
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length === 26);
  esit('Çevrimdışı Anime = 26', await page.$$eval('#list .item', (els) => els.length), 26);
  await page.click('#reset');

  // Adım 3: CSV dışa aktarma çevrimdışı da çalışmalı ve yeni sütunları içermeli
  await page.evaluate(() => { window.__csv = null; window.download = (name, content) => { window.__csv = { name, content }; }; });
  await page.click('#csv');
  await page.waitForFunction(() => window.__csv !== null);
  const csv = await page.evaluate(() => window.__csv);
  const baslik = csv.content.replace(/^\uFEFF/, '').split('\r\n')[0];
  dogru('Çevrimdışı CSV yeni sütunları içerir', baslik.includes('"turler"') && baslik.includes('"gozdenGecir"'));
  dogru('Çevrimdışı CSV 517 satır + başlık', csv.content.split('\r\n').length === 518);

  // Adım 4: uygunluk katmanı çevrimdışı da yüklenir ve çalışır
  const uy = await page.evaluate(() => {
    localStorage.clear(); uygunlukState = {};
    const yuk = loadUygunluk();
    uygunlukDuzelt('F-001', 'kategori', { kategori: 'siddet', seviye: 'orta' });
    return { yuk, sonuc: uygunlukGet('F-001').gecerli.sonuc, temelBos: Object.keys(UYGUNLUK_TEMEL).length === 0 };
  });
  dogru('Çevrimdışı uygunluk katmanı yüklendi', uy.yuk.ok);
  esit('Çevrimdışı uygunluk sonucu türetildi', uy.sonuc, 'uyari-ile');
  dogru('Çevrimdışı UYGUNLUK_TEMEL boş (uydurma yok)', uy.temelBos);

  await browser.close();
  console.log(`\nSONUÇ: ${gecen} geçti, ${kalan} kaldı`);
  process.exit(kalan ? 1 : 0);
})();
