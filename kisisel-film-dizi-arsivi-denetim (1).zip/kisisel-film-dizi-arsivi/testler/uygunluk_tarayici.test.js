// Aşama 3.4 Adım 4 — İçerik uygunluğu uçtan uca (tarayıcı) testleri.
// Ön koşul: http://localhost:12000 sunucusu. Çalıştırma: node testler/uygunluk_tarayici.test.js
const puppeteer = require('puppeteer-core');
const path = require('path');

const EXEC = '/usr/bin/chromium';
const URL = 'http://localhost:12000/index.html';
const FILE_URL = 'file://' + path.resolve(__dirname, '..', 'index.html');
const KEY = 'personal-film-series-archive-v1';
const UY_KEY = KEY + '__uygunluk';
const UY_BACKUP = KEY + '__uygunluk-backup';

let gecen = 0, kalan = 0;
function esit(ad, gercek, beklenen) {
  const ok = JSON.stringify(gercek) === JSON.stringify(beklenen);
  console.log(`  [${ok ? 'OK ' : 'HATA'}] ${ad}` + (ok ? '' : ` → gerçek=${JSON.stringify(gercek)} beklenen=${JSON.stringify(beklenen)}`));
  ok ? gecen++ : kalan++;
}
function dogru(ad, kosul) { esit(ad, !!kosul, true); }

// Yedek dosyasını dosya girişine yükler ve önizlemenin açılmasını bekler.
async function yedekYukle(page, obj) {
  await page.evaluate((o) => {
    const file = new File([JSON.stringify(o)], 'yedek.json', { type: 'application/json' });
    const dt = new DataTransfer(); dt.items.add(file);
    const input = document.getElementById('file');
    input.files = dt.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }, obj);
  await page.waitForFunction(() => !document.getElementById('iceModal').classList.contains('hidden'), { timeout: 5000 });
}

// Yedek yükler ama önizleme açılmasa da devam eder (red senaryoları için).
async function yedekDene(page, obj) {
  await page.evaluate(() => document.getElementById('iceModal').classList.add('hidden'));
  await page.evaluate((o) => {
    const file = new File([JSON.stringify(o)], 'yedek.json', { type: 'application/json' });
    const dt = new DataTransfer(); dt.items.add(file);
    const input = document.getElementById('file');
    input.files = dt.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }, obj);
  await new Promise((r) => setTimeout(r, 400));
}

(async () => {
  const browser = await puppeteer.launch({ executablePath: EXEC, headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  const hatalar = [], alerts = [];
  page.on('pageerror', (e) => hatalar.push('pageerror: ' + e.message));
  page.on('dialog', async (d) => { alerts.push(d.message()); await d.accept(); });

  await page.goto(URL, { waitUntil: 'networkidle0' });

  // ============================================================
  console.log('== A) Başlangıç: 517 kayıt, uygunluk katmanı temiz ==');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle0' });
  esit('katalog 517', await page.evaluate(() => catalog.length), 517);
  esit('uygunluk anahtarı boş', await page.evaluate((k) => localStorage.getItem(k), UY_KEY), null);
  esit('UYGUNLUK_TEMEL boş', await page.evaluate(() => Object.keys(UYGUNLUK_TEMEL).length), 0);
  const ozet0 = await page.evaluate(() => durumOzeti(catalog, UYGUNLUK_TEMEL, getUygunlukRaw()));
  esit('517 incelenmemiş', ozet0.incelenmemis, 517);

  // ============================================================
  console.log('\n== B) Kullanıcı düzeltmesi ayrı anahtara yazılır ==');
  const b = await page.evaluate((k) => {
    uygunlukDuzelt('F-001', 'kategori', { kategori: 'siddet', seviye: 'orta' });
    uygunlukDuzelt('F-001', 'kategori', { kategori: 'madde', seviye: 'yok' });
    return { ham: localStorage.getItem(k), gecerli: uygunlukGet('F-001') };
  }, UY_KEY);
  dogru('ayrı anahtar dolduruldu', b.ham !== null);
  esit('geçerli kategoriler', b.gecerli.gecerli.kategoriler, { siddet: 'orta', madde: 'yok' });
  esit('geçerli sonuç', b.gecerli.gecerli.sonuc, 'uyari-ile');
  esit('ana kullanıcı anahtarı boş kaldı', await page.evaluate((k) => localStorage.getItem(k), KEY), null);

  // ============================================================
  console.log('\n== C) JSON v2 dışa aktarma uygunluğu içerir ==');
  const json = await page.evaluate(() => {
    window.__json = null; window.download = (n, c) => { window.__json = { n, c }; };
    disaAktarJSON();
    return JSON.parse(window.__json.c);
  });
  esit('version 2', json.version, 2);
  esit('catalog 517', json.catalog.length, 517);
  dogru('uygunluk alanı var', !!json.uygunluk);
  esit('uygunluk F-001 taşındı', json.uygunluk['F-001'].kategoriler.siddet, 'orta');

  // ============================================================
  console.log('\n== D) v2 yedeğini geri yükle (Değiştir) ==');
  await page.evaluate(() => { uygunlukDuzelt('F-001', 'kategori', { kategori: 'siddet', seviye: 'yogun' }); });
  await yedekYukle(page, json); // dosyadaki siddet=orta
  await page.click('#iceDegistir');
  await new Promise((r) => setTimeout(r, 400));
  const dSonrasi = await page.evaluate(() => uygunlukGet('F-001').gecerli.kategoriler.siddet);
  esit('v2 Değiştir dosyadaki değeri uyguladı', dSonrasi, 'orta');

  // ============================================================
  console.log('\n== E) v1 yedeği mevcut uygunluk düzeltmesini SİLMEZ ==');
  await page.evaluate(() => { localStorage.setItem('personal-film-series-archive-v1__uygunluk', JSON.stringify({ 'F-002': { id: 'F-002', kategoriler: { madde: 'hafif' } } })); loadUygunluk(); });
  const v1 = { version: 1, exportedAt: '2020-01-01T00:00:00.000Z', ratingsAndPreferences: { 'F-003': { rating: 7 } } };
  await yedekYukle(page, v1);
  await page.click('#iceDegistir');
  await new Promise((r) => setTimeout(r, 400));
  const eSonrasi = await page.evaluate((k) => ({ uy: JSON.parse(localStorage.getItem(k) || '{}') }), UY_KEY);
  esit('v1 Değiştir sonrası uygunluk KORUNDU', eSonrasi.uy['F-002'].kategoriler.madde, 'hafif');

  // ============================================================
  console.log('\n== F) Bozuk uygunluk verisi güvenli reddedilir ==');
  const bozuk = { version: 2, ratingsAndPreferences: {}, uygunluk: { 'F-001': { id: 'F-001', kategoriler: { siddet: 'asiri' } } } };
  await yedekDene(page, bozuk);
  const modalAcik = await page.evaluate(() => !document.getElementById('iceModal').classList.contains('hidden'));
  esit('bozuk yedekte önizleme açılmadı', modalAcik, false);
  dogru('red uyarısı gösterildi', alerts.some((m) => m.includes('reddedildi') || m.includes('geçersiz') || m.includes('değiştirilmedi')));
  // çelişkili sonuç da reddedilmeli
  await yedekDene(page, { version: 2, ratingsAndPreferences: {}, uygunluk: { 'F-001': { id: 'F-001', kategoriler: { siddet: 'yogun' }, sonuc: 'birlikte-uygun' } } });
  esit('çelişkili yedekte önizleme açılmadı', await page.evaluate(() => !document.getElementById('iceModal').classList.contains('hidden')), false);

  // ============================================================
  console.log('\n== G) Sezon bazlı değerlendirme ==');
  const sezon = await page.evaluate(() => {
    const d = kayitDogrula({ id: 'D-001', kategoriler: { siddet: 'hafif' }, sezonlar: { 1: { kategoriler: { siddet: 'hafif' }, sonuc: 'uyari-ile' }, 2: { kategoriler: { siddet: 'yogun' }, sonuc: 'uygun-degil' } } });
    return { ok: d.ok, genel: sezonlardanSonuc(d.temiz.sezonlar) };
  });
  dogru('sezonlu kayıt geçerli', sezon.ok);
  esit('dizi geneli en kötü sezon', sezon.genel, 'uygun-degil');

  // ============================================================
  console.log('\n== H) Geri alma: uygunluk katmanı da geri döner ==');
  const h = await page.evaluate((uyKey, uyBk) => {
    localStorage.clear(); uygunlukState = {};
    uygunlukDuzelt('F-010', 'kategori', { kategori: 'siddet', seviye: 'hafif' });
    const onceki = JSON.parse(localStorage.getItem(uyKey));
    uygunlukBackupAl();                                   // içe aktarma öncesi yedek
    uygunlukDuzelt('F-010', 'kategori', { kategori: 'siddet', seviye: 'yogun' }); // değişiklik
    const degismis = JSON.parse(localStorage.getItem(uyKey));
    const ok = uygunlukGeriAl();                          // geri al
    const sonra = JSON.parse(localStorage.getItem(uyKey));
    return { onceki, degismis, ok, sonra, yedekVar: localStorage.getItem(uyBk) !== null };
  }, UY_KEY, UY_BACKUP);
  esit('değişiklik uygulandı', h.degismis['F-010'].kategoriler.siddet, 'yogun');
  dogru('geri alma başarılı', h.ok);
  esit('geri alınca önceki değer', h.sonra['F-010'].kategoriler.siddet, 'hafif');
  dogru('uygunluk yedeği alınmış', h.yedekVar);

  // ============================================================
  console.log('\n== I) Bozuk uygunluk ham verisi silinmez (loadUygunluk) ==');
  const i = await page.evaluate((k) => {
    localStorage.setItem(k, '{bozuk json');
    const r = loadUygunluk();
    const ham = localStorage.getItem(k);
    return { ok: r.ok, ham };
  }, UY_KEY);
  esit('loadUygunluk ok=false', i.ok, false);
  esit('ham bozuk veri silinmedi', i.ham, '{bozuk json');

  // ============================================================
  console.log('\n== J) Mevcut işlevler bozulmadı ==');
  await page.evaluate(() => { localStorage.clear(); });
  await page.reload({ waitUntil: 'networkidle0' });
  esit('kart sayısı 517', await page.$$eval('#list .item', (els) => els.length), 517);
  esit('toplam 517', await page.$eval('#total', (e) => e.textContent), '517');
  await page.evaluate(() => { const r = document.querySelector('#list .item .rating'); r.value = '9'; r.dispatchEvent(new Event('change', { bubbles: true })); });
  esit('puanlama çalışıyor', await page.$eval('#rated', (e) => e.textContent), '1');

  // ============================================================
  console.log('\n== K) Çevrimdışı (file://) uygunluk katmanı ==');
  const page2 = await browser.newPage();
  page2.on('dialog', async (d) => { await d.accept(); });
  await page2.goto(FILE_URL, { waitUntil: 'load' });
  const k = await page2.evaluate((uyKey) => {
    localStorage.clear(); uygunlukState = {};
    uygunlukDuzelt('F-001', 'kategori', { kategori: 'siddet', seviye: 'orta' });
    const json = { version: 2, ratingsAndPreferences: {}, uygunluk: JSON.parse(localStorage.getItem(uyKey)) };
    const a = analizEt(json, catalog, {});
    return { ok: a.ok, var: a.uygunlukVar, sonuc: uygunlukGet('F-001').gecerli.sonuc };
  }, UY_KEY);
  dogru('file:// analiz ok', k.ok);
  dogru('file:// uygunlukVar', k.var);
  esit('file:// sonuç türetildi', k.sonuc, 'uyari-ile');

  esit('Sayfa hatası yok', hatalar, []);

  await browser.close();
  console.log(`\nSONUÇ: ${gecen} geçti, ${kalan} kaldı`);
  process.exit(kalan ? 1 : 0);
})();
