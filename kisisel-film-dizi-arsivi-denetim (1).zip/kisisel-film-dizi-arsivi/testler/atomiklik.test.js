// Atomiklik testi: yazma sırasında hata olursa mevcut veri korunmalı.
// Çalıştırma: node testler/atomiklik.test.js
const puppeteer = require('puppeteer-core');

const EXEC = '/usr/bin/chromium';
const URL = 'http://localhost:12000/index.html';

let gecen = 0, kalan = 0;
function esit(ad, gercek, beklenen) {
  const ok = JSON.stringify(gercek) === JSON.stringify(beklenen);
  console.log(`  [${ok ? 'OK ' : 'HATA'}] ${ad}` + (ok ? '' : ` → gerçek=${JSON.stringify(gercek)} beklenen=${JSON.stringify(beklenen)}`));
  ok ? gecen++ : kalan++;
}

(async () => {
  const browser = await puppeteer.launch({ executablePath: EXEC, headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  const alerts = [];
  page.on('dialog', async (d) => { alerts.push(d.message()); await d.accept(); });

  await page.goto(URL, { waitUntil: 'networkidle0' });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle0' });

  // Mevcut veri oluştur
  await page.evaluate(() => {
    localStorage.setItem('personal-film-series-archive-v1', JSON.stringify({ 'F-100': { rating: 4 } }));
  });
  await page.reload({ waitUntil: 'networkidle0' });
  const onceki = await page.evaluate(() => localStorage.getItem('personal-film-series-archive-v1'));

  console.log('== Yazma hatası simülasyonu ==');
  // localStorage.setItem'i ana anahtar için hata verecek şekilde geçici olarak boz
  await page.evaluate(() => {
    const orijinal = localStorage.setItem.bind(localStorage);
    window.__orijinalSetItem = orijinal;
    localStorage.setItem = function (k, v) {
      if (k === 'personal-film-series-archive-v1') throw new Error('kota dolu (simülasyon)');
      return orijinal(k, v);
    };
  });

  // Geçerli yedek yükle ve Değiştir'e bas
  await page.evaluate(() => {
    const obj = { version: 1, ratingsAndPreferences: { 'F-001': { rating: 10 }, 'F-002': { rating: 9 } } };
    const file = new File([JSON.stringify(obj)], 'yedek.json', { type: 'application/json' });
    const dt = new DataTransfer(); dt.items.add(file);
    const input = document.getElementById('file'); input.files = dt.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  });
  await page.waitForFunction(() => !document.getElementById('iceModal').classList.contains('hidden'));
  await page.click('#iceDegistir');
  await new Promise((r) => setTimeout(r, 400));

  const sonraki = await page.evaluate(() => localStorage.getItem('personal-film-series-archive-v1'));
  esit('Yazma hatasında veri değişmedi', sonraki, onceki);
  esit('Hata uyarısı gösterildi', alerts.some((m) => m.includes('yazma hatası') || m.includes('korundu')), true);

  await browser.close();
  console.log(`\nSONUÇ: ${gecen} geçti, ${kalan} kaldı`);
  process.exit(kalan ? 1 : 0);
})();
