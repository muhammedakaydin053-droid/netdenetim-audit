// Aşama 3.4 Adım 4 — İçerik uygunluğu veri modeli (saf fonksiyonlar).
// Çalıştırma: node testler/uygunluk.test.js
const fs = require('fs');
const path = require('path');
const U = require('../js/uygunluk.js');
const { analizEt, hesaplaYeniUygunlukDurum, DESTEKLENEN_SURUM } = require('../js/iceaktarma.js');

const veriSrc = fs.readFileSync(path.join(__dirname, '..', 'js', 'veri.js'), 'utf8');
const catalog = eval('(' + veriSrc.replace(/^const catalog=/, '').replace(/;\s*$/, '') + ')');

let gecen = 0, kalan = 0;
function esit(ad, gercek, beklenen) {
  const ok = JSON.stringify(gercek) === JSON.stringify(beklenen);
  console.log(`  [${ok ? 'OK ' : 'HATA'}] ${ad}` + (ok ? '' : ` → gerçek=${JSON.stringify(gercek)} beklenen=${JSON.stringify(beklenen)}`));
  ok ? gecen++ : kalan++;
}
function dogru(ad, kosul) { esit(ad, !!kosul, true); }

console.log('== A) Sabitler ==');
esit('5 kategori', U.KATEGORILER, ['siddet', 'cinsellik', 'korkutucu', 'agirDil', 'madde']);
esit('5 seviye', U.SEVIYELER, ['yok', 'hafif', 'orta', 'yogun', 'bilinmiyor']);
esit('4 genel sonuç', U.SONUCLAR, ['birlikte-uygun', 'uyari-ile', 'uygun-degil', 'bekliyor']);
esit('durumlar', U.DURUMLAR, ['degerlendirildi', 'kismen-degerlendirildi', 'kaynak-bulunamadi', 'incelenmemis', 'kullanici-duzeltmesi']);
esit('desteklenen yedek sürümü 2', DESTEKLENEN_SURUM, 2);

console.log('\n== B) sonucTuret kuralları ==');
esit('boş → bekliyor', U.sonucTuret({}), 'bekliyor');
esit('hepsi yok → birlikte-uygun', U.sonucTuret({ siddet: 'yok', cinsellik: 'yok', korkutucu: 'yok', agirDil: 'yok', madde: 'yok' }), 'birlikte-uygun');
esit('hafif → uyari-ile', U.sonucTuret({ siddet: 'hafif' }), 'uyari-ile');
esit('orta → uyari-ile', U.sonucTuret({ siddet: 'orta' }), 'uyari-ile');
esit('yogun → uygun-degil', U.sonucTuret({ siddet: 'yogun' }), 'uygun-degil');
esit('yogun baskın (orta+yogun)', U.sonucTuret({ siddet: 'orta', madde: 'yogun' }), 'uygun-degil');
esit('hepsi bilinmiyor → bekliyor', U.sonucTuret({ siddet: 'bilinmiyor', madde: 'bilinmiyor' }), 'bekliyor');
esit('yok+bilinmiyor → bekliyor (eksik bilgi)', U.sonucTuret({ siddet: 'yok', cinsellik: 'bilinmiyor' }), 'bekliyor');
esit('geçersiz girdi → bekliyor', U.sonucTuret(null), 'bekliyor');

console.log('\n== C) sezonlardanSonuc (en kötü sezon) ==');
esit('boş → null', U.sezonlardanSonuc({}), null);
esit('en kötü sezon kazanır', U.sezonlardanSonuc({ 1: { sonuc: 'birlikte-uygun' }, 2: { sonuc: 'uygun-degil' }, 3: { sonuc: 'uyari-ile' } }), 'uygun-degil');
esit('uyari > birlikte', U.sezonlardanSonuc({ 1: { sonuc: 'birlikte-uygun' }, 2: { sonuc: 'uyari-ile' } }), 'uyari-ile');
esit('tek sezon', U.sezonlardanSonuc({ 1: { sonuc: 'uyari-ile' } }), 'uyari-ile');

console.log('\n== D) kayitDogrula — geçerli kayıt ==');
let d = U.kayitDogrula({ id: 'F-001', kategoriler: { siddet: 'orta', madde: 'yok' } });
dogru('geçerli', d.ok);
esit('sonuç türetildi', d.temiz.sonuc, 'uyari-ile');
esit('durum varsayılan incelenmemis', d.temiz.durum, 'incelenmemis');

console.log('\n== E) kayitDogrula — geçersiz kayıtlar ==');
dogru('nesne değil reddi', U.kayitDogrula(null).ok === false);
dogru('kategoriler yok reddi', U.kayitDogrula({ id: 'F-001' }).ok === false);
dogru('geçersiz seviye reddi', U.kayitDogrula({ id: 'F-001', kategoriler: { siddet: 'cok-yogun' } }).ok === false);
dogru('bilinmeyen kategori reddi', U.kayitDogrula({ id: 'F-001', kategoriler: { uzay: 'yok' } }).ok === false);
dogru('geçersiz sonuç reddi', U.kayitDogrula({ id: 'F-001', kategoriler: { siddet: 'yok' }, sonuc: 'harika' }).ok === false);
dogru('id yok reddi', U.kayitDogrula({ kategoriler: { siddet: 'yok' } }).ok === false);

console.log('\n== F) kayitDogrula — çelişkili sonuç reddi (veri tutarlılığı) ==');
const celiski = U.kayitDogrula({ id: 'F-001', kategoriler: { siddet: 'yogun' }, sonuc: 'birlikte-uygun' });
dogru('çelişki reddedildi', celiski.ok === false);
dogru('çelişki nedeni sonuc alanı', celiski.hatalar.some((h) => h.field === 'sonuc' && h.reason.includes('çelişkili')));
const tutarli = U.kayitDogrula({ id: 'F-001', kategoriler: { siddet: 'yogun' }, sonuc: 'uygun-degil' });
dogru('tutarlı sonuç kabul', tutarli.ok === true);

console.log('\n== G) kaynak/kanıt doğrulama ==');
dogru('kaynak adı yoksa reddi', U.kayitDogrula({ id: 'F-001', kategoriler: { siddet: 'yok' }, kaynaklar: [{ url: 'x' }] }).ok === false);
dogru('geçersiz güven reddi', U.kayitDogrula({ id: 'F-001', kategoriler: { siddet: 'yok' }, kaynaklar: [{ ad: 'IMDb', guven: 'cok-yuksek' }] }).ok === false);
const kaynakli = U.kayitDogrula({
  id: 'F-001',
  kategoriler: { siddet: 'hafif' },
  kaynaklar: [{ ad: 'IMDb Parents Guide', url: 'https://example.org', kontrolTarihi: '2025-01-01', kategoriler: ['siddet'], guven: 'orta', surumEslesme: 'F-001' }],
});
dogru('geçerli kaynak kabul', kaynakli.ok === true);
esit('kaynak korundu', kaynakli.temiz.kaynaklar.length, 1);

console.log('\n== H) Sezon doğrulama ==');
const sezonlu = U.kayitDogrula({ id: 'D-001', kategoriler: { siddet: 'hafif' }, sezonlar: { 1: { kategoriler: { siddet: 'hafif' }, sonuc: 'uyari-ile' }, 2: { kategoriler: { siddet: 'yogun' }, sonuc: 'uygun-degil' } } });
dogru('sezonlu kayıt geçerli', sezonlu.ok === true);
dogru('geçersiz sezon seviyesi reddi', U.kayitDogrula({ id: 'D-001', kategoriler: { siddet: 'yok' }, sezonlar: { 1: { kategoriler: { siddet: 'asiri' } } } }).ok === false);
esit('sezonlardanSonuc dizi geneli', U.sezonlardanSonuc(sezonlu.temiz.sezonlar), 'uygun-degil');

console.log('\n== I) birlestir — kaynak + kullanıcı düzeltmesi ==');
const b = U.birlestir({ id: 'F-001', kategoriler: { siddet: 'hafif', madde: 'yok' } }, { kategoriler: { siddet: 'yogun' }, kullaniciNotu: 'bence daha ağır' });
esit('kullanıcı düzeltmesi uygulandı', b.gecerli.kategoriler.siddet, 'yogun');
esit('kaynak diğer kategori korundu', b.gecerli.kategoriler.madde, 'yok');
esit('sonuç yeniden türetildi', b.gecerli.sonuc, 'uygun-degil');
esit('kaynak verisi SİLİNMEDİ', b.kaynak.kategoriler.siddet, 'hafif');
esit('düzeltilen alanlar raporlandı', b.duzeltilenAlanlar.sort(), ['kategoriler.siddet', 'kullaniciNotu']);

console.log('\n== J) birlestir — kullanıcı kaydı yoksa kaynak aynen ==');
const b2 = U.birlestir({ id: 'F-002', kategoriler: { siddet: 'orta' } }, undefined);
esit('kategoriler kaynaktan', b2.gecerli.kategoriler, { siddet: 'orta' });
esit('düzeltme yok', b2.duzeltilenAlanlar, []);

console.log('\n== K) bilinmeyen → yok değil (kritik kural) ==');
const b3 = U.birlestir(null, undefined);
esit('kayıt yokken sonuç bekliyor', b3.gecerli.sonuc, 'bekliyor');
esit('durum incelenmemis', b3.gecerli.durum, 'incelenmemis');
dogru('bilinmiyor seviyesi bilinmiyor sayılır', U.sonucTuret({ siddet: 'bilinmiyor' }) === 'bekliyor');

console.log('\n== L) UYGUNLUK_TEMEL boş (değerlendirme uydurulmadı) ==');
esit('temel veri boş', Object.keys(U.UYGUNLUK_TEMEL).length, 0);

console.log('\n== M) durumOzeti — 517 kayıtla ==');
const ozet = U.durumOzeti(catalog, U.UYGUNLUK_TEMEL, {});
esit('toplam 517', ozet.toplam, 517);
esit('hiç değerlendirilmiş yok', ozet.degerlendirildi, 0);
esit('517 incelenmemiş', ozet.incelenmemis, 517);
esit('517 bekliyor', ozet.bekliyor, 517);
const ozet2 = U.durumOzeti(catalog, {}, { 'F-001': { kategoriler: { siddet: 'hafif' } } });
esit('kullanıcı düzeltmeli sayısı 1', ozet2.kullaniciDuzeltmeli, 1);
esit('bekliyor 516', ozet2.bekliyor, 516);

console.log('\n== N) analizEt — uygunluk katmanı ==');
const v1 = analizEt({ version: 1, ratingsAndPreferences: { 'F-001': { rating: 5 } } }, catalog, {});
dogru('v1 ok', v1.ok);
esit('v1 uygunlukVar false', v1.uygunlukVar, false);
const v2 = analizEt({ version: 2, ratingsAndPreferences: {}, uygunluk: { 'F-001': { id: 'F-001', kategoriler: { siddet: 'hafif' } } } }, catalog, {});
dogru('v2 ok', v2.ok);
esit('v2 uygunlukVar true', v2.uygunlukVar, true);
esit('v2 uygunlukSayisi 1', v2.uygunlukSayisi, 1);
dogru('bozuk uygunluk reddi', analizEt({ version: 2, ratingsAndPreferences: {}, uygunluk: { 'F-001': { kategoriler: { siddet: 'asiri' } } } }, catalog, {}).ok === false);
dogru('uygunluk nesne değilse reddi', analizEt({ version: 2, ratingsAndPreferences: {}, uygunluk: [] }, catalog, {}).ok === false);
dogru('bilinmeyen ID içeren uygunluk reddi', analizEt({ version: 2, ratingsAndPreferences: {}, uygunluk: { 'F-999': { id: 'F-999', kategoriler: { siddet: 'yok' } } } }, catalog, {}).ok === false);

console.log('\n== O) hesaplaYeniUygunlukDurum — v1 mevcut düzeltmeyi SİLMEZ ==');
const mevcutUy = { 'F-001': { id: 'F-001', kategoriler: { siddet: 'yogun' } } };
const y1 = hesaplaYeniUygunlukDurum('degistir', v1, mevcutUy);
esit('v1 + degistir → mevcut korunur', y1, mevcutUy);
const y2 = hesaplaYeniUygunlukDurum('birlestir', v1, mevcutUy);
esit('v1 + birlestir → mevcut korunur', y2, mevcutUy);
const y3 = hesaplaYeniUygunlukDurum('degistir', v2, mevcutUy);
esit('v2 + degistir → dosyadaki', Object.keys(y3), ['F-001']);
esit('v2 + degistir içerik', y3['F-001'].kategoriler.siddet, 'hafif');
const v2b = analizEt({ version: 2, ratingsAndPreferences: {}, uygunluk: { 'F-002': { id: 'F-002', kategoriler: { madde: 'yok' } } } }, catalog, {});
const y4 = hesaplaYeniUygunlukDurum('birlestir', v2b, mevcutUy);
esit('v2 + birlestir → birleşim', Object.keys(y4).sort(), ['F-001', 'F-002']);
esit('v2 + birlestir mevcut korundu', y4['F-001'].kategoriler.siddet, 'yogun');

console.log(`\nSONUÇ: ${gecen} geçti, ${kalan} kaldı`);
process.exit(kalan ? 1 : 0);
