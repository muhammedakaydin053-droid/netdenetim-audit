// Aşama 3.4 Adım 1 — Çoklu tür filtresi, arama kapsamı ve sınıflandırılmamış filtre testi.
// Gerçek Chromium (headless). Ön koşul: http://localhost:12000 üzerinde sunucu.
// Çalıştırma: node testler/filtre.test.js
const puppeteer = require('puppeteer-core');

const EXEC = '/usr/bin/chromium';
const URL = 'http://localhost:12000/index.html';

let gecen = 0, kalan = 0;
function esit(ad, gercek, beklenen) {
  const ok = JSON.stringify(gercek) === JSON.stringify(beklenen);
  console.log(`  [${ok ? 'OK ' : 'HATA'}] ${ad}` + (ok ? '' : ` → gerçek=${JSON.stringify(gercek)} beklenen=${JSON.stringify(beklenen)}`));
  ok ? gecen++ : kalan++;
}

// Paneldeki bir türü işaretle (checkbox + change olayı).
async function turSec(page, ad) {
  await page.evaluate((t) => {
    const cb = [...document.querySelectorAll('#turPanel input[type="checkbox"]')].find((c) => c.value === t);
    if (cb) { cb.checked = true; cb.dispatchEvent(new Event('change', { bubbles: true })); }
  }, ad);
}
async function turTemizle(page, ad) {
  await page.evaluate((t) => {
    const cb = [...document.querySelectorAll('#turPanel input[type="checkbox"]')].find((c) => c.value === t);
    if (cb) { cb.checked = false; cb.dispatchEvent(new Event('change', { bubbles: true })); }
  }, ad);
}
const kartSayisi = (page) => page.$$eval('#list .item', (els) => els.length);

(async () => {
  const browser = await puppeteer.launch({ executablePath: EXEC, headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  const hatalar = [];
  page.on('pageerror', (e) => hatalar.push('pageerror: ' + e.message));

  await page.goto(URL, { waitUntil: 'networkidle0' });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle0' });

  console.log('== A) Panel ve temel durum ==');
  const turSayisi = await page.$$eval('#turPanel input[type="checkbox"]', (els) => els.length);
  esit('Panelde 19 ana tür', turSayisi, 19);
  esit('Başlangıç 517 kart', await kartSayisi(page), 517);

  console.log('\n== B) Tek tür (OR grubu) ==');
  await turSec(page, 'Korku');
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length === 36);
  esit('Korku = 36', await kartSayisi(page), 36);
  await turTemizle(page, 'Korku');
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length === 517);

  console.log('\n== C) Çoklu tür → OR ==');
  await turSec(page, 'Korku');
  await turSec(page, 'Bilim kurgu');
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length === 116);
  esit('Korku OR Bilim kurgu = 116', await kartSayisi(page), 116);

  // OR doğrulaması: sonuç kümesi, tek tek kümelerin birleşiminden küçük olamaz.
  const korkuOnly = 36, bilimOnly = 85, birlesim = 116;
  esit('OR birleşim tutarlı (36 + 85 - 5 kesişim = 116)', korkuOnly + bilimOnly - birlesim, 5);

  await turTemizle(page, 'Korku');
  await turTemizle(page, 'Bilim kurgu');
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length === 517);

  console.log('\n== D) Tür grubu + kind grubu → AND ==');
  await page.select('#kind', 'Dizi');
  await turSec(page, 'Korku');
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length === 12);
  esit('Korku AND Dizi = 12', await kartSayisi(page), 12);
  await page.click('#reset');
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length === 517);

  console.log('\n== E) Arama yeni taksonomiyi kapsıyor ==');
  await page.type('#q', 'Dedektif');
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length < 40);
  esit('Arama "Dedektif" (alt tür) = 25', await kartSayisi(page), 25);
  await page.click('#reset');

  await page.type('#q', 'Gerçek olay');
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length > 0);
  esit('Arama "Gerçek olay" (etiket) = 22', await kartSayisi(page), 22);
  await page.click('#reset');

  await page.type('#q', 'Klasik');
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length > 0);
  esit('Arama "Klasik" (etiket) = 17', await kartSayisi(page), 17);
  await page.click('#reset');

  await page.type('#q', 'Godfather');
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length < 10);
  esit('Arama "Godfather" (başlık) = 2', await kartSayisi(page), 2);
  await page.click('#reset');
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length === 517);

  console.log('\n== F) Sınıflandırılmamış filtresi ==');
  await page.click('#sinifsiz');
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length === 4);
  esit('Sınıflandırılmamış = 4', await kartSayisi(page), 4);
  const basliklar = await page.$$eval('#list .item .title', (els) => els.map((e) => e.textContent).sort());
  esit('Sınıflandırılmamış kayıtlar doğru', basliklar, ['8½', 'Persona', 'The Square', 'The Tree of Life']);
  const etiket = await page.$eval('#list .item .tag', (e) => e.textContent);
  esit('Kart etiketi "sınıflandırılmamış" gösterir', etiket.includes('sınıflandırılmamış'), true);

  console.log('\n== G) Sınıflandırılmamış + tür → OR ==');
  await turSec(page, 'Dram');
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length === 324);
  esit('Dram OR sınıflandırılmamış = 324', await kartSayisi(page), 324);
  await page.click('#reset');
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length === 517);
  esit('Reset sonrası 517', await kartSayisi(page), 517);

  console.log('\n== H) Sayfa hatası yok ==');
  esit('pageerror yok', hatalar, []);

  await browser.close();
  console.log(`\nSONUÇ: ${gecen} geçti, ${kalan} kaldı`);
  process.exit(kalan ? 1 : 0);
})();
