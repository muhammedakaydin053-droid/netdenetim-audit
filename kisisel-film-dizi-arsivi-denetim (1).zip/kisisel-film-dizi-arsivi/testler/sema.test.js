// Aşama 2 şema/migration mantığı testleri (saf fonksiyonlar).
// Çalıştırma: node testler/sema.test.js
const { durumTuret, kayitIncele, migrationPlanla, GUNCEL_SEMA, SEMA_META_KEY, MIGRATION_BACKUP_KEY } = require('../js/sema.js');

let gecen = 0, kalan = 0;
function esit(ad, gercek, beklenen) {
  const ok = JSON.stringify(gercek) === JSON.stringify(beklenen);
  console.log(`  [${ok ? 'OK ' : 'HATA'}] ${ad}` + (ok ? '' : ` → gerçek=${JSON.stringify(gercek)} beklenen=${JSON.stringify(beklenen)}`));
  ok ? gecen++ : kalan++;
}

console.log('== Sabitler ==');
esit('GUNCEL_SEMA = 2', GUNCEL_SEMA, 2);
esit('meta anahtarı', SEMA_META_KEY, 'personal-film-series-archive-v1__meta');
esit('migration yedek anahtarı (içe aktarma yedeğinden ayrı)', MIGRATION_BACKUP_KEY, 'personal-film-series-archive-v1__migration-backup');

console.log('\n== İzleme durumu türetimi (watched → status) ==');
esit('watched true → izlendi', durumTuret({ watched: true }), 'izlendi');
esit('watched false → izlenmedi', durumTuret({ watched: false }), 'izlenmedi');
esit('watched yok → izlenecek', durumTuret({ rating: 5 }), 'izlenecek');
esit('boş kayıt → izlenecek', durumTuret({}), 'izlenecek');
esit('null → izlenecek', durumTuret(null), 'izlenecek');
esit('sayı → izlenecek', durumTuret(5), 'izlenecek');
esit('tarih içermez (yalnızca durum metni)', durumTuret({ watched: true }), 'izlendi');

console.log('\n== Kayıt inceleme (silmeme, yalnızca rapor) ==');
let i1 = kayitIncele('F-001', { watched: true, rating: 9, favorite: true, rank: 1 });
esit('geçerli kayıt → sorun yok', i1.sorunlar, []);
esit('geçerli kayıt → bilinmeyen alan yok', i1.bilinmeyen, []);
let i2 = kayitIncele('F-002', { watched: 'evet', rating: 0, rank: -3 });
esit('geçersiz watched/rating/rank → 3 sorun', i2.sorunlar.length, 3);
let i3 = kayitIncele('F-003', { watched: true, ozelEtiket: 'x', not: 'y' });
esit('bilinmeyen alanlar tespit edilir (silinmez)', i3.bilinmeyen, ['ozelEtiket', 'not']);
esit('bilinmeyen alanlar sorun sayılmaz', i3.sorunlar, []);
let i4 = kayitIncele('F-004', 'metin');
esit('kayıt nesne değilse sorun bildirir', i4.sorunlar.length, 1);

console.log('\n== Migration planı: sürüm geçişleri ==');
let p1 = migrationPlanla({ 'F-001': { watched: true, rating: 9 } }, {});
esit('v1 (meta yok) → gerekti true', p1.gerekti, true);
esit('v1 → fromVersion 1', p1.fromVersion, 1);
esit('v1 → toVersion 2', p1.toVersion, 2);
esit('v1 → yeniMeta {_schema:2, migratedFrom:1}', p1.yeniMeta, { _schema: 2, migratedFrom: 1 });

let p2 = migrationPlanla({ 'F-001': { watched: true } }, { _schema: 2 });
esit('v2 → gerekti false (idempotent)', p2.gerekti, false);

let p3 = migrationPlanla({}, { _schema: 2, migratedFrom: 1 });
esit('v2 + migratedFrom → gerekti false', p3.gerekti, false);

console.log('\n== Migration planı: hata durumları (veri değişmez) ==');
let p4 = migrationPlanla({ 'F-001': {} }, { _schema: 3 });
esit('ileri sürüm (3) → ok false', p4.ok, false);
esit('ileri sürüm → hata mesajı', p4.error.includes('Desteklenmeyen şema'), true);
let p5 = migrationPlanla({}, { _schema: 'iki' });
esit('bozuk _schema (metin) → ok false', p5.ok, false);
let p6 = migrationPlanla({}, null);
esit('bozuk meta (null) → ok false', p6.ok, false);
let p7 = migrationPlanla({}, { _schema: -1 });
esit('negatif sürüm → ok false', p7.ok, false);

console.log('\n== Migration raporu ==');
let p8 = migrationPlanla({
  'F-001': { watched: true, rating: 9 },
  'F-002': { rating: 0 },              // geçersiz
  'F-003': { watched: true, not: 'x' }, // bilinmeyen alan
}, {});
esit('rapor toplam kayıt', p8.rapor.toplamKayit, 3);
esit('rapor sorunlu kayıt', p8.rapor.sorunluKayit, 1);
esit('rapor geçersiz değer', p8.rapor.gecersizDegerler.length, 1);
esit('rapor bilinmeyen alan', p8.rapor.bilinmeyenAlanlar.length, 1);

console.log('\n== Idempotentlik (tekrar migration veriyi değiştirmez) ==');
// İlk migration meta üretir; o meta ile ikinci plan "gerekti false" olmalı.
let ilk = migrationPlanla({ 'F-001': { watched: true } }, {});
let ikinci = migrationPlanla({ 'F-001': { watched: true } }, ilk.yeniMeta);
esit('ikinci kez migration gerekmez', ikinci.gerekti, false);
esit('ikinci kez meta değişmez', ikinci.yeniMeta, ilk.yeniMeta);

console.log('\n== state nesne değilse güvenli davranış ==');
let p9 = migrationPlanla(null, {});
esit('state null → çökmez, ok true', p9.ok, true);
esit('state null → toplam kayıt 0', p9.rapor.toplamKayit, 0);
let p10 = migrationPlanla([1, 2, 3], {});
esit('state dizi → çökmez, kayıt 0', p10.rapor.toplamKayit, 0);

console.log(`\nSONUÇ: ${gecen} geçti, ${kalan} kaldı`);
process.exit(kalan ? 1 : 0);
