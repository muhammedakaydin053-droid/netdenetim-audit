// BAĞIMSIZ KONTROL — Aşama 1 (mevcut testlerden ayrı).
// Kullanıcının istediği 1, 2, 3, 5 numaralı kontrolleri bağımsız olarak doğrular.
// Çalıştırma: node testler/bagimsiz_kontrol.test.js
const puppeteer = require('puppeteer-core');
const fs = require('fs');
const path = require('path');
const { analizEt, hesaplaYeniDurum, raporOlustur } = require('../js/iceaktarma.js');

const EXEC = '/usr/bin/chromium';
const URL = 'http://localhost:12000/index.html';
const KEY = 'personal-film-series-archive-v1';
const BACKUP_KEY = KEY + '__backup';

let gecen = 0, kalan = 0;
function esit(ad, gercek, beklenen) {
  const ok = JSON.stringify(gercek) === JSON.stringify(beklenen);
  console.log(`  [${ok ? 'OK ' : 'HATA'}] ${ad}` + (ok ? '' : ` → gerçek=${JSON.stringify(gercek)} beklenen=${JSON.stringify(beklenen)}`));
  ok ? gecen++ : kalan++;
}

const veriSrc = fs.readFileSync(path.join(__dirname, '..', 'js', 'veri.js'), 'utf8');
const catalog = eval('(' + veriSrc.replace(/^const catalog=/, '').replace(/;\s*$/, '') + ')');

(async () => {
  // ============ #1 Birleştir/Değiştir alan davranışları (saf fonksiyonlar) ============
  console.log('== #1) Birleştir/Değiştir: alan koruma, eksik/geçersiz/bilinmeyen ==');

  // Tüm alanlar geçerli
  const mevcutA = { 'F-001': { watched: true, favorite: true, rating: 9, rank: 2 } };
  const dosyaA = { version: 1, ratingsAndPreferences: { 'F-001': { watched: false, favorite: false, rating: 5, rank: 7 } } };
  let aA = analizEt(dosyaA, catalog, mevcutA);
  esit('Birleştir: 4 alan da dosyadan güncellendi', hesaplaYeniDurum('birlestir', aA, mevcutA)['F-001'], { watched: false, favorite: false, rating: 5, rank: 7 });
  esit('Değiştir: 4 alan da dosyadan', hesaplaYeniDurum('degistir', aA, mevcutA)['F-001'], { watched: false, favorite: false, rating: 5, rank: 7 });

  // Eksik alan: dosyada yalnızca rating var; Birleştir'de diğer alanlar korunur
  const mevcutB = { 'F-002': { watched: true, favorite: true, rank: 3 } };
  const dosyaB = { version: 1, ratingsAndPreferences: { 'F-002': { rating: 6 } } };
  let aB = analizEt(dosyaB, catalog, mevcutB);
  esit('Birleştir: eksik alanlar korunur', hesaplaYeniDurum('birlestir', aB, mevcutB)['F-002'], { watched: true, favorite: true, rank: 3, rating: 6 });
  esit('Değiştir: eksik alanlar düşer', hesaplaYeniDurum('degistir', aB, mevcutB)['F-002'], { rating: 6 });

  // Geçersiz değer: rating 0, rank -1, watched "yes" → atlanır; favorite true kalır
  const dosyaC = { version: 1, ratingsAndPreferences: { 'F-003': { rating: 0, rank: -1, watched: 'yes', favorite: true } } };
  let aC = analizEt(dosyaC, catalog, {});
  esit('Geçersizler atlandı, yalnızca favorite kaldı', aC.valid['F-003'], { favorite: true });
  esit('3 geçersiz değer raporlandı', aC.invalidValues.length, 3);

  // Sınır değerler: rating 1 ve 10 geçerli; rank 1 geçerli
  const dosyaD = { version: 1, ratingsAndPreferences: { 'F-004': { rating: 1, rank: 1 }, 'F-005': { rating: 10 } } };
  let aD = analizEt(dosyaD, catalog, {});
  esit('rating 1 geçerli', aD.valid['F-004'], { rating: 1, rank: 1 });
  esit('rating 10 geçerli', aD.valid['F-005'], { rating: 10 });

  // Sınır dışı: rating 11, rank 0
  const dosyaE = { version: 1, ratingsAndPreferences: { 'F-006': { rating: 11, rank: 0 } } };
  let aE = analizEt(dosyaE, catalog, {});
  esit('rating 11 geçersiz', aE.invalidValues.length, 2);
  esit('F-006 geçerli kayıt oluşmadı', aE.valid['F-006'], undefined);

  // Bilinmeyen ID: katalogda yok → atlanır, valid'e girmez
  const dosyaF = { version: 1, ratingsAndPreferences: { 'ZZZ-1': { rating: 5 }, 'F-007': { rating: 5 } } };
  let aF = analizEt(dosyaF, catalog, {});
  esit('Bilinmeyen ID atlandı', aF.unknownIds, ['ZZZ-1']);
  esit('Bilinmeyen ID valid\'e girmedi', Object.keys(aF.valid), ['F-007']);

  // Boole false değerleri korunur
  const dosyaG = { version: 1, ratingsAndPreferences: { 'F-008': { watched: false, favorite: false } } };
  let aG = analizEt(dosyaG, catalog, {});
  esit('false değerler korunur', aG.valid['F-008'], { watched: false, favorite: false });

  // ============ Tarayıcı gerektiren kontroller ============
  const browser = await puppeteer.launch({ executablePath: EXEC, headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  const alerts = [];
  page.on('dialog', async (d) => { alerts.push(d.message()); await d.accept(); });
  const hatalar = [];
  page.on('pageerror', (e) => hatalar.push(e.message));

  await page.goto(URL, { waitUntil: 'networkidle0' });

  // ============ #2 Yedekleme başarısızsa içe aktarma durmalı ============
  console.log('\n== #2) Yedekleme başarısızsa içe aktarma durmalı ==');
  await page.evaluate((k) => localStorage.clear(), null);
  await page.evaluate((k, bk) => {
    localStorage.setItem(k, JSON.stringify({ 'F-100': { rating: 4 } }));
  }, KEY, BACKUP_KEY);
  await page.reload({ waitUntil: 'networkidle0' });
  const onceki = await page.evaluate((k) => localStorage.getItem(k), KEY);

  // BACKUP_KEY yazımını boz
  await page.evaluate((bk) => {
    const orijinal = localStorage.setItem.bind(localStorage);
    window.__orig = orijinal;
    localStorage.setItem = function (k, v) { if (k === bk) throw new Error('yedek yazılamadı (simülasyon)'); return orijinal(k, v); };
  }, BACKUP_KEY);

  await page.evaluate(() => {
    const obj = { version: 1, ratingsAndPreferences: { 'F-001': { rating: 10 } } };
    const file = new File([JSON.stringify(obj)], 'y.json', { type: 'application/json' });
    const dt = new DataTransfer(); dt.items.add(file);
    const i = document.getElementById('file'); i.files = dt.files; i.dispatchEvent(new Event('change', { bubbles: true }));
  });
  await page.waitForFunction(() => !document.getElementById('iceModal').classList.contains('hidden'));
  await page.click('#iceDegistir');
  await new Promise((r) => setTimeout(r, 400));
  esit('Yedek başarısız → veri değişmedi', await page.evaluate((k) => localStorage.getItem(k), KEY), onceki);
  esit('Yedek başarısız → uyarı gösterildi', alerts.some((m) => m.includes('yedek alınamadı') || m.includes('durduruldu')), true);
  await page.evaluate(() => { localStorage.setItem = window.__orig; });

  // ============ #3 Geri alma hata durumunda veriyi korumalı ============
  console.log('\n== #3) Geri alma hatasında veri korunmalı ==');
  await page.evaluate((k, bk) => {
    localStorage.setItem(k, JSON.stringify({ 'F-200': { rating: 8 } }));
    localStorage.setItem(bk, '{ bu bozuk json');   // bozuk yedek
  }, KEY, BACKUP_KEY);
  await page.reload({ waitUntil: 'networkidle0' });
  const oncesi3 = await page.evaluate((k) => localStorage.getItem(k), KEY);
  await page.click('#geriAl');
  await new Promise((r) => setTimeout(r, 150));
  await page.click('#geriAlOnay');
  await new Promise((r) => setTimeout(r, 300));
  esit('Bozuk yedek → veri korundu', await page.evaluate((k) => localStorage.getItem(k), KEY), oncesi3);
  esit('Bozuk yedek → hata uyarısı', alerts.some((m) => m.includes('geri yüklenemedi')), true);

  // ============ #5 Eski arama/filtre/sıralama/favori/puanlama davranışı ============
  console.log('\n== #5) Eski arama/filtre/sıralama/favori/puanlama korundu mu ==');
  await page.evaluate((k, bk) => { localStorage.removeItem(k); localStorage.removeItem(bk); }, KEY, BACKUP_KEY);
  await page.reload({ waitUntil: 'networkidle0' });

  // Filtreler (orijinal mantıkla aynı beklenen değerler)
  await page.select('#kind', 'Dizi');
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length === 178);
  esit('kind=Dizi → 178', await page.$$eval('#list .item', (els) => els.length), 178);
  await page.click('#reset');

  await page.evaluate(() => {
    const cb = [...document.querySelectorAll('#turPanel input[type="checkbox"]')].find((c) => c.value === 'Dram');
    cb.checked = true;
    cb.dispatchEvent(new Event('change', { bubbles: true }));
  });
  const dramCount = await page.$$eval('#list .item', (els) => els.length);
  esit('tur=Dram → 320', dramCount, 320);
  await page.click('#reset');

  // Sıralama: A-Z ilk öğe F-226, Z-A ilk öğe son harf
  const azFirst = await page.$eval('#list .item .title', (e) => e.textContent);
  esit('A-Z ilk öğe 12 Angry Men', azFirst, '12 Angry Men');
  await page.select('#sort', 'za');
  const zaFirst = await page.$eval('#list .item .title', (e) => e.textContent);
  esit('Z-A ilk öğe Zodiac', zaFirst, 'Zodiac');
  await page.click('#reset');

  // Favori ekleme
  await page.evaluate(() => { document.querySelector('#list .item .fav').click(); });
  await page.waitForFunction(() => document.getElementById('favcount').textContent === '1');
  esit('Favori eklendi → favcount=1', await page.$eval('#favcount', (e) => e.textContent), '1');
  const favState = await page.evaluate((k) => JSON.parse(localStorage.getItem(k)), KEY);
  esit('Favori state\'e yazıldı (F-226 favorite=true)', favState['F-226'].favorite, true);

  // Puanlama
  await page.evaluate(() => { const r = document.querySelector('#list .item .rating'); r.value = '7'; r.dispatchEvent(new Event('change', { bubbles: true })); });
  esit('Puanlama → rated=1', await page.$eval('#rated', (e) => e.textContent), '1');

  // Durum filtresi: izlediklerim
  await page.select('#status', 'rated');
  esit('status=rated → 1', await page.$$eval('#list .item', (els) => els.length), 1);
  await page.click('#reset');

  // Arama
  await page.type('#q', 'Matrix');
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length < 5);
  esit('Arama "Matrix" → 1', await page.$$eval('#list .item', (els) => els.length), 1);
  await page.click('#reset');

  esit('Sayfa hatası yok', hatalar, []);

  await browser.close();
  console.log(`\nSONUÇ: ${gecen} geçti, ${kalan} kaldı`);
  process.exit(kalan ? 1 : 0);
})();
