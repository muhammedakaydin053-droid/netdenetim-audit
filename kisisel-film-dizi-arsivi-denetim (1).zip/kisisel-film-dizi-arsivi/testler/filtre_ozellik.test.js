// Aşama 3.4 Adım 2 — Etiket ve özellik filtreleri testi.
// Gerçek Chromium (headless). Ön koşul: http://localhost:12000 üzerinde sunucu.
// Çalıştırma: node testler/filtre_ozellik.test.js
const puppeteer = require('puppeteer-core');

const EXEC = '/usr/bin/chromium';
const URL = 'http://localhost:12000/index.html';

let gecen = 0, kalan = 0;
function esit(ad, gercek, beklenen) {
  const ok = JSON.stringify(gercek) === JSON.stringify(beklenen);
  console.log(`  [${ok ? 'OK ' : 'HATA'}] ${ad}` + (ok ? '' : ` → gerçek=${JSON.stringify(gercek)} beklenen=${JSON.stringify(beklenen)}`));
  ok ? gecen++ : kalan++;
}

async function turSec(page, ad, deger = true) {
  await page.evaluate((t, d) => {
    const cb = [...document.querySelectorAll('#turPanel input[type="checkbox"]')].find((c) => c.value === t);
    if (cb) { cb.checked = d; cb.dispatchEvent(new Event('change', { bubbles: true })); }
  }, ad, deger);
}
async function etiketSec(page, ad, deger = true) {
  await page.evaluate((t, d) => {
    const cb = [...document.querySelectorAll('#etPanel input[type="checkbox"]')].find((c) => c.value === t);
    if (cb) { cb.checked = d; cb.dispatchEvent(new Event('change', { bubbles: true })); }
  }, ad, deger);
}
async function cipTikla(page, alan, deger) {
  await page.evaluate((a, d) => {
    const b = [...document.querySelectorAll('#filtreEk .cip')].find((x) => x.dataset.alan === a && x.dataset.deger === d);
    if (b) b.click();
  }, alan, deger);
}
const kart = (page) => page.$$eval('#list .item', (els) => els.length);
const bekle = (page, n) => page.waitForFunction((m) => document.querySelectorAll('#list .item').length === m, {}, n);

(async () => {
  const browser = await puppeteer.launch({ executablePath: EXEC, headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  const hatalar = [];
  page.on('pageerror', (e) => hatalar.push('pageerror: ' + e.message));

  await page.goto(URL, { waitUntil: 'networkidle0' });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle0' });

  console.log('== A) Panel doluluğu ==');
  esit('Etiket panelinde 6 seçenek', await page.$$eval('#etPanel input[type="checkbox"]', (els) => els.length), 6);
  esit('Özellik çipi sayısı (2 ortam + 1 biçim + 2 gelenek)', await page.$$eval('#filtreEk .cip', (els) => els.length), 5);
  esit('Başlangıç 517 kart', await kart(page), 517);

  console.log('\n== B) Her etiketin doğru sayısı ==');
  const etBekle = { 'Klasik': 17, 'Dünya sineması': 5, 'Bağımsız/Sanat sineması': 15, 'Gerçek olay': 22, 'Okul': 7, 'Gençlik': 10 };
  for (const [ad, n] of Object.entries(etBekle)) {
    await etiketSec(page, ad, true);
    await bekle(page, n);
    esit(`Etiket "${ad}" = ${n}`, await kart(page), n);
    await etiketSec(page, ad, false);
    await bekle(page, 517);
  }

  console.log('\n== C) Etiket OR ==');
  await etiketSec(page, 'Klasik');
  await etiketSec(page, 'Gençlik');
  await bekle(page, 27);
  esit('Klasik OR Gençlik = 27', await kart(page), 27);
  await page.click('#reset');
  await bekle(page, 517);

  console.log('\n== D) Özellik: ortam ==');
  await cipTikla(page, 'ortam', 'Animasyon');
  await bekle(page, 49);
  esit('Ortam=Animasyon = 49', await kart(page), 49);
  await cipTikla(page, 'ortam', 'Animasyon');

  await cipTikla(page, 'ortam', 'Canlı aksiyon');
  await bekle(page, 468);
  esit('Ortam=Canlı aksiyon = 468 (ortam alanı olmayanlar dahil)', await kart(page), 468);
  await page.click('#reset');
  await bekle(page, 517);

  console.log('\n== E) Özellik: animasyonGelenegi (ortamdan ayrı) ==');
  await cipTikla(page, 'animasyonGelenegi', 'Anime');
  await bekle(page, 26);
  esit('Animasyon geleneği=Anime = 26', await kart(page), 26);
  await cipTikla(page, 'animasyonGelenegi', 'Anime');

  await cipTikla(page, 'animasyonGelenegi', 'Batı');
  await bekle(page, 23);
  esit('Animasyon geleneği=Batı = 23', await kart(page), 23);
  await page.click('#reset');
  await bekle(page, 517);

  console.log('\n== F) Özellik: bicim ==');
  await cipTikla(page, 'bicim', 'Mini dizi');
  await bekle(page, 9);
  esit('Biçim=Mini dizi = 9', await kart(page), 9);
  await page.click('#reset');
  await bekle(page, 517);

  console.log('\n== G) Gruplar arası AND ==');
  // Tür grubu + kind
  await turSec(page, 'Korku');
  await page.select('#kind', 'Dizi');
  await bekle(page, 12);
  esit('Korku AND Dizi = 12', await kart(page), 12);
  await page.click('#reset');
  await bekle(page, 517);

  // Tür + etiket + kind: (Korku OR Gerilim) AND Gençlik
  await turSec(page, 'Korku');
  await turSec(page, 'Gerilim');
  await etiketSec(page, 'Gençlik');
  await bekle(page, 1);
  esit('(Korku OR Gerilim) AND Gençlik = 1', await kart(page), 1);
  await page.click('#reset');
  await bekle(page, 517);

  // Özellik grubu + etiket: Animasyon AND Gerçek olay
  await cipTikla(page, 'ortam', 'Animasyon');
  await etiketSec(page, 'Gerçek olay');
  const animGercek = await kart(page);
  esit('Animasyon AND Gerçek olay = 0', animGercek, 0);
  await page.click('#reset');
  await bekle(page, 517);

  // Mini dizi AND Gerçek olay = 2
  await cipTikla(page, 'bicim', 'Mini dizi');
  await etiketSec(page, 'Gerçek olay');
  await bekle(page, 2);
  esit('Mini dizi AND Gerçek olay = 2', await kart(page), 2);
  await page.click('#reset');
  await bekle(page, 517);

  console.log('\n== H) Tür + etiket + özellik + kind birlikte ==');
  await turSec(page, 'Bilim kurgu');
  await cipTikla(page, 'ortam', 'Animasyon');
  await page.select('#kind', 'Dizi');
  const kombin = await kart(page);
  // Bilim kurgu + Animasyon + Dizi
  esit('Bilim kurgu AND Animasyon AND Dizi = 9', kombin, 9);
  await page.click('#reset');
  await bekle(page, 517);

  console.log('\n== I) Sınıflandırılmamış erişilebilir ==');
  await page.click('#sinifsiz');
  await bekle(page, 4);
  esit('Sınıflandırılmamış = 4', await kart(page), 4);
  // Etiket (ayrı grup) ile sınıflandırılmamış (tür grubu) arası AND.
  // Sınıflandırılmamış 4 kayıttan Dünya sineması etiketi olanlar: F-314, F-315 → 2.
  await etiketSec(page, 'Dünya sineması');
  const dunyaVeSinifsiz = await kart(page);
  esit('Sınıflandırılmamış AND Dünya sineması = 2', dunyaVeSinifsiz, 2);
  await page.click('#reset');
  await bekle(page, 517);

  console.log('\n== J) Aktif filtre özeti ==');
  await turSec(page, 'Korku');
  await etiketSec(page, 'Gençlik');
  await cipTikla(page, 'ortam', 'Animasyon');
  const ozet = await page.$eval('#aktifFiltre', (e) => e.textContent);
  esit('Özet tür içerir', ozet.includes('Tür: Korku'), true);
  esit('Özet etiket içerir', ozet.includes('Etiket: Gençlik'), true);
  esit('Özet ortam içerir', ozet.includes('Ortam: Animasyon'), true);

  console.log('\n== K) Tüm filtreleri sıfırlama ==');
  await page.click('#reset');
  await bekle(page, 517);
  esit('Reset sonrası 517', await kart(page), 517);
  esit('Reset etiket temizlendi', await page.$$eval('#etPanel input:checked', (els) => els.length), 0);
  esit('Reset çipler temizlendi', await page.$$eval('#filtreEk .cip[aria-pressed="true"]', (els) => els.length), 0);
  esit('Reset tür temizlendi', await page.$$eval('#turPanel input:checked', (els) => els.length), 0);
  esit('Reset sonrası özet boş', await page.$eval('#aktifFiltre', (e) => e.textContent), '');

  console.log('\n== L) Klavye erişilebilirliği (native checkbox + buton) ==');
  // Panel gizliyken checkbox odaklanamaz (display:none); önce paneli aç.
  await page.click('#etBtn');
  const etKlavye = await page.evaluate(() => {
    const cb = document.querySelector('#etPanel input[type="checkbox"]');
    cb.focus();
    return document.activeElement === cb;
  });
  esit('Etiket checkbox odaklanabilir (panel açıkken)', etKlavye, true);
  // Boşluk tuşu native checkbox'ı işaretler.
  await page.keyboard.press('Space');
  await bekle(page, 17);
  esit('Klavye Boşluk ile etiket seçildi (Klasik=17)', await kart(page), 17);
  await page.click('#reset');
  await bekle(page, 517);
  const cipKlavye = await page.evaluate(() => {
    const b = document.querySelector('#filtreEk .cip');
    b.focus();
    return document.activeElement === b;
  });
  esit('Çip butonu odaklanabilir', cipKlavye, true);
  // Enter/Boşluk ile buton tıklaması (native button davranışı)
  await page.evaluate(() => {
    const b = [...document.querySelectorAll('#filtreEk .cip')].find((x) => x.dataset.deger === 'Mini dizi');
    b.focus();
  });
  await page.keyboard.press('Enter');
  await bekle(page, 9);
  esit('Klavye Enter ile çip aktif → Mini dizi = 9', await kart(page), 9);
  await page.click('#reset');

  console.log('\n== M) Mevcut işlevler bozulmadı ==');
  await page.select('#kind', 'Dizi');
  await bekle(page, 178);
  esit('kind=Dizi → 178', await kart(page), 178);
  await page.click('#reset');
  await page.type('#q', 'Godfather');
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length === 2);
  esit('Arama "Godfather" = 2', await kart(page), 2);
  await page.click('#reset');
  await bekle(page, 517);
  esit('pageerror yok', hatalar, []);

  console.log('\n== N) Dar ekranda taşma yok ==');
  for (const gen of [375, 414, 768]) {
    await page.setViewport({ width: gen, height: 800 });
    await new Promise((r) => setTimeout(r, 120));
    const tasma = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    esit(`${gen}px genişlikte yatay taşma yok`, tasma <= 1, true);
  }
  await page.setViewport({ width: 1280, height: 900 });

  await browser.close();
  console.log(`\nSONUÇ: ${gecen} geçti, ${kalan} kaldı`);
  process.exit(kalan ? 1 : 0);
})();
